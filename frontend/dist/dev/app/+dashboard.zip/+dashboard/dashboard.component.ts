import { Component } 			from '@angular/core';
import { Http, Headers, Jsonp } from '@angular/http';
import { Injectable } 			from '@angular/core';

import { EdekaService }			from '../services/edeka.service';

@Component({
  selector: 'sd-dashboard',
  templateUrl: 'app/+dashboard/dashboard.component.html',
  styleUrls: ['app/+dashboard/dashboard.component.css'],
  providers: [EdekaService]
})
/**
 * This class represents the lazy loaded DashboardComponent.
 */
export class DashboardComponent {
	scrapedData: any[];
	totalData: number;
	interId: number;

	constructor(private edekaService: EdekaService) {
		this.edekaService.getScrapedData().subscribe((p:any) => { 
				console.log("Scraped_EDEKA: ", Object.values(JSON.parse(p['resultData']));
					this.scrapedData = JSON.parse(p['resultData']);
					this.totalData = this.scrapedData.length;
					console.log('data: ', this.keyOfScraoedData);
				});
	}	

	onStartScrapy() {
		// this.edekaService.getFoods().subscribe((p:any) => { console.log("111EDEKA: ", p); });
		this.edekaService.postStartScrapy().subscribe((p:any) => { console.log("POST_EDEKA: ", p); });
		
		this.interId = setInterval( () => {
			this.edekaService.getScrapedData().subscribe((p:any) => { 
				console.log("Scraped_EDEKA: ", JSON.parse(p['resultData']));
					this.scrapedData = JSON.parse(p['resultData']);
					this.totalData = this.scrapedData.length;
					this.scrapyStatus = p['scrapyStatus'];
					console.log("status: ", this.scrapyStatus);

					if ( this.scrapyStatus === 'finished' ) {
						clearInterval(this.interId);
					}
				})
			}
			,
			1000
		);

		
	}

	onEndScrapy() {
		this.edekaService.postEndScrapy().subscribe((p:any) => { console.log("End Service: ", p); });
		clearInterval(this.interId);}
	}
}